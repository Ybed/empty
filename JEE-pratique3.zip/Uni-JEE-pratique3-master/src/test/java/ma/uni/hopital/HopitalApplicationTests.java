package ma.uni.hopital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HopitalApplicationTests {

    @Test
    void contextLoads() {
    }

}
